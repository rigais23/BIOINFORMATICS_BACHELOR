#include<iostream>
using namespace std;

int main() {

    int x;

    while (cin >> x){

        int s = 0;

        cout << "The sum of the digits of " << x << " is ";

        
        while(x != 0){
            s += x%10;
            x /= 10;
            
        }

        cout << s << "." << endl;
    }
}