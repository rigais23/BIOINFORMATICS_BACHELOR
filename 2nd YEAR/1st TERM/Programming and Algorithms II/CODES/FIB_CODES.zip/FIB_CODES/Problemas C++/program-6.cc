#include<iostream>
using namespace std;

int main() {
    string a = "", b = "", x;

    while (cin >> x) {
        if(x > b and x != a) {
            if (x >= a) {
                b = a;
                a = x;
            }
            else b = x;
        }
    }

    if (b != "") cout << b << endl;
}