#include<iostream>
using namespace std;

int main() {

    int f, c;

    cin >> f >> c;

    int n = 9;


        for (int i = 0; i < f; ++i){
            for (int j = 0; j < c; ++j){
                cout << n;
                --n;
                if (n == -1) n = 9;
            }
            cout << endl;
        }

    while (cin >> f){
    
        n = 9;
        cin >> c;

        cout << endl;

        for (int i = 0; i < f; ++i){
            for (int j = 0; j < c; ++j){
                cout << n;
                --n;
                if (n == -1) n = 9;
            }
            cout << endl;
        }

        


    }
}