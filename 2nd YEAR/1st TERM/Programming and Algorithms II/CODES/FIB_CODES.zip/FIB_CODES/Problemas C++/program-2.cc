#include<iostream>
using namespace std;

int main() {

    int b, n;

    while(cin >> b){

        int d = 0;

        cin >> n;

        if (n == 0) d = 1;
        else {
            while (n != 0){
                ++d;
                n /= b;
            }
        }

        cout << d << endl;

    }
}