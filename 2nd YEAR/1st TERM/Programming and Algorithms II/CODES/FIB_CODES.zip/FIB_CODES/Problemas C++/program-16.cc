#include<iostream>
#include<vector>
using namespace std;

int main(){
    int size;

    while (cin >> size){
        if (size != 0){
        vector<int> V(size);

        for (int i = 0; i < size; ++i) cin >> V[i];

        for (int i = size-1; i > 0; --i) cout << V[i] << " ";

        cout << V[0];

        }

        cout << endl;
    }
}