import sys

num=sys.stdin.readline().strip()

def bars_3(n):
	L=list()
	if n==1:
		L.append('*')
		return L
	
	else:
		return bars_3(n-1)+bars_3(n-1)+['*'*n]

result=bars_3(int(num))

for elem in result:
	print(elem)
