import sys


def SEC_MAX(llista):
	S=set()
	for elem in llista:
		S.add(elem)
	sort=sorted(S)
	
	return sort[-2]

L=list()
for line in sys.stdin:
	name=line.strip()
	L.append(name)

result=SEC_MAX(L)
print(result)
