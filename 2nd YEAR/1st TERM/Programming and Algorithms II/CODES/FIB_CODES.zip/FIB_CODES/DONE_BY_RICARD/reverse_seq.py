import sys

def REVERSE(s):
	L=list()
	
	if len(s)==0:
		return L
	
	else:
		return [s[-1]]+REVERSE(s[:-1])
		


for linia in sys.stdin:
	defi=linia.strip().split()
	result=REVERSE(defi[1:])
	
	for elem in result:
		print(elem, end=' ')
	print()	

