import sys

posicio=sys.stdin.readline().strip()
posicio=int(posicio)

llista=sys.stdin.readline().strip().split()

def TH(pos,lis):
	s=THS(pos,lis,1)
	return f'At the position {pos} there is a(n) {s}.'

def THS(pos,lis,n):
	if n == pos:
		return lis[n-1]
	
	else:
		return THS(pos,lis,n+1)


result=TH(posicio,llista)

print(result)
