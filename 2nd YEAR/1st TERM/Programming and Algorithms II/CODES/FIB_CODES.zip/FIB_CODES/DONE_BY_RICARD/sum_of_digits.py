import sys

def SUM(n):
	s=SUMA(n)
	return f'The sum of the digits of {n} is {s}.'

def SUMA(n):
	if n<=9:
		return n
	
	else:
		return n%10+SUMA(n//10)

for num in sys.stdin:
	numero=num.strip()
	result=SUM(int(numero))
	print(result)
