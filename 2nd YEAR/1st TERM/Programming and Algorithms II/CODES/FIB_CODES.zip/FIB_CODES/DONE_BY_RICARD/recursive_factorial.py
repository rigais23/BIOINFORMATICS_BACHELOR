import sys

num=sys.stdin.readline().strip()

def factorial(n):
	if n <=1:
		return 1
	else:
		return n*factorial(n-1)


result=factorial(int(num))
print(result)
