import sys

def bars_1(n):
	L=list()
	if n==1:
		L.append('*')
		return L
	
	else:
		return bars_1(n-1)+['*'*n]+bars_1(n-1)

num=sys.stdin.readline().strip()

result=bars_1(int(num))

for elem in result:
	print(elem)
