import sys


def STATISTICAL(s):
	L=[int(s[1]),int(s[1]),0]
	STATI(s[1:],L)
	L[2]=int(L[2])/int(s[0])
	return L

def STATI(s,L):
	if len(s)==0:
		return 
	
	else:
		if int(s[0]) < int(L[0]):
			L[0]=int(s[0])
		
		if int(s[0]) > int(L[1]):
			L[1]=int(s[0])

		L[2]=int(L[2])+int(s[0])
		
		return STATI(s[1:],L)

nums=sys.stdin.readline().strip().split()

for numeros in sys.stdin:
	linia=numeros.strip().split()
	result=STATISTICAL(linia)
	for elem in result:
		elem=int(elem)
		print("{:.4f}".format(elem),end=' ') #to print all elements in same line
		print()
