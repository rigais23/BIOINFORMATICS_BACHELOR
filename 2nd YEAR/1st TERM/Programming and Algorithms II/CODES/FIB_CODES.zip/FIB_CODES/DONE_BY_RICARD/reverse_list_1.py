import sys


def REVERSE(q):
	L=list()
	
	if len(q)==0:
		return L
	
	else:
		return [q[-1]] + REVERSE(q[:-1])




llista=list()
for nom in sys.stdin:
	cur_nom=nom.strip()
	llista.append(cur_nom)

result=REVERSE(llista)


for elem in result:
	print(elem)
