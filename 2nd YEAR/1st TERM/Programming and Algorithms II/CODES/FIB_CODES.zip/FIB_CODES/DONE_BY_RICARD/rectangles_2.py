import sys

def RECTANGLES(n,m):
	L=list()
	REC(n,m,9,L)
	return L

def REC(f,c,w,L):
	if f==0:
		return 
	
	else:
		P=list()
		for _ in range(c):
			P.append(w)
			w-=1
			if w < 0:
				w=9
		L+=P
		REC(f-1,c,w,L)
				
first=sys.stdin.readline().strip()
second=sys.stdin.readline().strip()

result=RECTANGLES(int(first),int(second))

for _ in range(int(first)):
	stri=''
	for x in range(0,int(second)):
		stri+=str(result[x])
	print(stri)
	result=result[int(second):]
	
	
