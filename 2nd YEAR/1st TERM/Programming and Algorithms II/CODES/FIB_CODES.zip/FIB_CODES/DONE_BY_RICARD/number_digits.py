import sys

num=sys.stdin.readline().strip()

def number_of_digits(n):
	if n<=9:
		return 1
	
	else:
		return 1 + number_of_digits(n//10)

result=number_of_digits(int(num))

print(result)
