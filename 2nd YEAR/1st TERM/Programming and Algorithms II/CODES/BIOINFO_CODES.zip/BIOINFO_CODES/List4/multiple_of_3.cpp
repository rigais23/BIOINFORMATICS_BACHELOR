#include <iostream>

using namespace std;

int sum_of_digits(int n){
	if(n<=9){
		return n;
	}
	else{
		return n%10 + sum_of_digits(n/10);
	}
	
}

bool is_multiple_3(int n){
	if(n<=9){
		return n%3==0;
	}
	else{
		return is_multiple_3(sum_of_digits(n));
	}
	
}

int main(){
	int number;
	cin >> number;
	
	bool result = is_multiple_3(number);
	
	cout<<result<<endl;
	
	return 0;
}

//in c++ we can define two functions separetly and then with main define which has to be executed.
