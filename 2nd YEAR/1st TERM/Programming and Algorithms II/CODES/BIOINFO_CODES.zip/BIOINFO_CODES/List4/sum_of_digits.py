import sys

def sum_of_digits(n):
	if n<=9:
		return n
	
	else:
		return n%10 + sum_of_digits(n//10)



for line in sys.stdin:
	number=line.strip()
	
	result=sum_of_digits(int(number))
	print('The sum of the digits of ',number,' is ',result,'.',sep='')
	
