def is_multiple_3(n):
	
	def sum_of_digits(n):
		if n<=9:
			return n
	
		else:
			return n%10+sum_of_digits(n//10)
		
	if n<=9:
		return n%3==0
	
	else:
		return is_multiple_3(sum_of_digits(n))




#In python we define the main function an isnide we define the sub function
