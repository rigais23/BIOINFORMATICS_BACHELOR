import sys

def SLIDING_WINDOW(s,x,y):
	if len(s)<int(x):
		return []
	else:
		return [s[0:int(x)]] + (SLIDING_WINDOW(s[int(y):],int(x),int(y)))





s=sys.stdin.readline().strip()
x=sys.stdin.readline().strip()
y=sys.stdin.readline().strip()

result=SLIDING_WINDOW(s,x,y)


for elem in result:
	print(elem)


	
