#include <iostream>
#include <string>
#include <vector>


using namespace std;

vector<string> SLIDING_WINDOW(string s, int x, int y){
		vector<string> L;
		if(s.length()<x){
			return  vector<string> ();
		}
		else{
			L=SLIDING_WINDOW(s.substr(y),x,y);
			L.insert(L.begin(),s.substr(0,x));
			return L;

		}
	
	
}



int main(){
	string s;
	int x;
	int y;
	
	cin>>s>>x>>y;
	
	vector<string> result=SLIDING_WINDOW(s,x,y);
	
	for(string elements:result){
		cout<<elements<<endl;
	}
	return 0;
	}
