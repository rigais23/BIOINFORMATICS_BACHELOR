#include <iostream>
#include <vector>
#include <string>

using namespace std;

vector<string> SLIDE_WINDOW(string s, int x, int y){
	vector<string> result;
	
	while(s.length()>=x){
		result.push_back(s.substr(0,x));
		s=s.substr(y);
	}
	return result;
	
}

int main(){
	string s;
	int x;
	int y;
	
	cin >>s>>x>>y;
	
	vector<string> result=SLIDE_WINDOW(s,x,y);
	
	for(string sub: result){
		cout << sub <<endl;
		}
	
	
	return 0;
}
