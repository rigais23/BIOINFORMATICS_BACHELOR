import sys

def SLIDING_WINDOW(s,x,y):
	x=int(x)
	y=int(y)
	result=[]
	
	while len(s)>=x:
		result.append(s[0:x])
		s=s[y:]
	
	return result






s=sys.stdin.readline().strip()
x=sys.stdin.readline().strip()
y=sys.stdin.readline().strip()

result=SLIDING_WINDOW(s,x,y)

for elemin in result:
	print(elemin)
