#include <iostream>
#include <string>

using namespace std;

int sum_of_digits(int n){
	if(n<=9){
		return n;
	}
	else{
		return n%10 + sum_of_digits(n/10);
	}
}

int main(){
	int number;
	
	while(cin>>number){
		int result= sum_of_digits(number);
	
		cout << "The sum of the digits of "<< number<< " is " << result<<'.'<< endl;
	}
}
