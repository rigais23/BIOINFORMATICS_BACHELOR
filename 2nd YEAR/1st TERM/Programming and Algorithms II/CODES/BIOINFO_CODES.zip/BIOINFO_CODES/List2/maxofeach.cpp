#include <iostream>
#include <vector>

using namespace std;

int MaxValue(vector<int> vector_each){
    int max;
    bool first = true;
    for(int i=0; i < vector_each.size();i++ ){
        if(first){
            max=vector_each[i];
            first=false;
        }
        else{
            if(vector_each[i]>max){
                max=vector_each[i];
            }
        }
    }
    return max;
}


int main(){
    int num_values;
    int value;

    while(cin >> num_values){
        vector<int> vector_each;
        for(int o=0; o<num_values; o++){
            cin >> value;
            vector_each.push_back(value);
        }
        int final=MaxValue(vector_each);
        cout << final << endl;
    }
}
    