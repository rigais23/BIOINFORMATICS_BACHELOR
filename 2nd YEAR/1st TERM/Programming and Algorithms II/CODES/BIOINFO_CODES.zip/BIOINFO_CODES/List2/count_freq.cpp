#include <iostream>
#include <map>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;

map<string,int> count_freq(vector<string> senten){
    map<string, int> dic;

    for(int i=0; i<senten.size();i++){
        string elem=senten[i];
        if(dic.find(elem) != dic.end()){
            dic[elem]++;
        }
        else{
            dic[elem]=1;
        }
    }
    return dic;
}

int main(){
    int num_values;
    string elem;
    vector<string> senten;
    while(cin >> num_values){
        for(int i=0;i<num_values;i++){
            cin >> elem;
            senten.push_back(elem);
            }
   
        map<string, int> final=count_freq(senten);
        for(auto& pair:final){ //important to use &
            cout<<pair.first << " : " << pair.second <<endl;
        }
    
    }
    return 0;

}