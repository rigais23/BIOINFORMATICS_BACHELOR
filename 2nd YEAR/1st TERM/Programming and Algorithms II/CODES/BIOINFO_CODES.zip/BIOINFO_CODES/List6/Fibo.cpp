#include <iostream>

using namespace std;

int FIBO(int n);

int FIBONACCI(int n, int m){
	int newe=FIBO(n);
	
	return newe%m;
	}

int FIBO(int n){
	if(n<=1){
		return n;
		}
	
	else{
		return FIBO(n-1)+FIBO(n-2);
		}
	
	}

int main(){
	int n;
	int m;
	
	cin >> n;
	cin >> m;
	
	int RESULT= FIBONACCI(n,m);
	
	cout << RESULT << endl;
	
	return 0;
	
	
	}
