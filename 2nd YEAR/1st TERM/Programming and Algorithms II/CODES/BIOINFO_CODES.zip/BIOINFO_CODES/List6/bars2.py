import sys

num=sys.stdin.readline().strip()
num=int(num)

def BARS(n):
	L=list()
	
	if n==1:
		L.append('*')
		return L
	
	else:
		return ['*'*n] + BARS(n-1) + BARS(n-1)

result=BARS(num)

for elem in result:
	print(elem)
