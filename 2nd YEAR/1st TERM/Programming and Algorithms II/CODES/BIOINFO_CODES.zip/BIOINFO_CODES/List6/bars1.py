import sys


num=sys.stdin.readline().strip()
num=int(num)


def BARSI(x):
	R=list()
	
	if x==1:
		R.append('*')
		return R
	
	else:
		return BARSI(x-1) + ['*'*x] + BARSI(x-1)
		

result= BARSI(num)

for elem in result:
	print(elem)
