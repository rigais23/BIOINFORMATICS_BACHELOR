import sys

seq=sys.stdin.readline().strip()

def PERMUTATIONS(s):
	L=list()
	L=PER(s,0)
	return L

def PER(s,k):
	R=list()
	if k==len(s):
		R.append(s)
		return R
	
	else:
		P=list()
		i=k
		
		for x in range(i,len(s)):
			P.append(s[x],s[k]=s[k],s[x])
		
		return P + PER(s,k+1)

result=PERMUTATIONS(seq)

for elem in sorted(result):
	print(elem)
			
