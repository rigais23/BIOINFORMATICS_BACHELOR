#include <iostream>
#include <vector>
#include <string>

using namespace std;

vector<string> BARS(int x){
	vector<string> R;
	
	if(x==1){
		R.push_back('*');
		return R;
		}
	else{
		return BARS(x-1) + ('*'*x) + BARS(x-1);
		}
	
	}
	
int main(){
	int num;
	cin>>num;
	
	vector<string> result = BARS(num);
	
	for(string vec: result){
		cout<<vec<<endl;
		}

	}
