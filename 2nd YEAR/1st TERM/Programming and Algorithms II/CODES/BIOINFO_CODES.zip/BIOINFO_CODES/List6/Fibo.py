import sys

def FIBONACCI(n,m):
	new=FIBO(n)
	return new%m

def FIBO(n):
	if n<=1:
		return n
	
	else:
		return FIBO(n-1)+FIBO(n-2)


red=sys.stdin.readline().strip().split()

n=int(red[0])
m=int(red[1])

result=FIBONACCI(n,m)

print(result)
