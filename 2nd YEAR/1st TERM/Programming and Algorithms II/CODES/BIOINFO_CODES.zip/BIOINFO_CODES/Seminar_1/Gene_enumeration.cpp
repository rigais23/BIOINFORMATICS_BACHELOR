#include <iostream>
#include <string>
#include <set>

using namespace std;

//call function
string GENE_ENUMERATION(string seq);

int main(){
    // read input
    string seq;
    cin >> seq;

    if(seq.length() <=0){
        return 0;
    }

    GENE_ENUMERATION(seq);
    return 0;
}

//define function
string GENE_ENUMERATION(string seq){
    int i=0;
    int leng=seq.length();
    set<string> stop ={"TGA","TAA", "TAG"};

    while((i+3)<=leng){
        if(seq.substr(i,3)=="ATG"){
            int j=i+3;

            while((j+2)<=leng){
                if(stop.find(seq.substr(j,3))!=stop.end()){
                    cout << seq.substr(i,j+3-i)<<endl;
                    //take a string from the beggining of the start codon to the end of the stop codon
                    break;
                }
                j=j+3;
            }
        }
        i++;
    }
    return("");
}

