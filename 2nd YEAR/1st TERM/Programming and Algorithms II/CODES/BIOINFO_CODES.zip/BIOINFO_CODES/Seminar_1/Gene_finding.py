import sys

s=sys.stdin.readline()


def GENE_FINDING(s):
    leng=len(s)

    i = 0
    
    while i + 3 <= leng: 
        if s[i:i+3] == 'ATG':
            j = i + 3
            while j + 2 <= leng:
                if s[j:j+3] in {'TAA', 'TAG', 'TGA'}:
                    return s[i:j+3]
                j=j+3
        i = i + 1
    return ''

x=GENE_FINDING(s)

if x!='':
    print(x)



    
