import sys

s=sys.stdin.readline().strip()

def GENE_ENUMERATION(s):
    leng=len(s)
    i=0

    while i + 3 <= leng: #no me cuadra el 3
        if s[i:i+3] =="ATG": #el 3 no se cuenta, es como un range, no te coje el i+3
            j=i+3

            while j+2 <= leng:
                if s[j:j+3] in {"TAA","TAG","TGA"}:
                    print(s[i:j+3])
                    break #to exit the while loop
                j+=3
        
        i+=1
    
    return(None)

GENE_ENUMERATION(s) #why??????????

