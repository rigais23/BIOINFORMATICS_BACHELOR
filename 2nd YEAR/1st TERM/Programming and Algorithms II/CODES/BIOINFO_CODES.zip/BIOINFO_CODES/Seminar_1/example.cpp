#include <iostream>

using namespace std;

void swapNumbers(int a, int b);

int main(){

   int x, y;

   while (cin >> x >> y){
        cout << "Before swap: " << x << ' ' << y << endl;
        swapNumbers(x, y);
        cout << "After swap: " << x << ' ' << y << endl;
   }
  
   return 0;
}

void swapNumbers(int a, int b){

    int aux = a;
    a = b;
    b = aux;
}