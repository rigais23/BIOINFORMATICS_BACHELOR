#include <iostream>
#include <string>
#include <set>

using namespace std;

string GENE_FINDING(string s);

int main(){
    string s;
    cin >> s;
    string x=GENE_FINDING(s);

    if(x != ""){
        cout<< x<< endl;
    }
    return 0;
}

string GENE_FINDING(string s){
    int len = s.length();
    int i =0;
    set<string> stop = {"TAA","TAG", "TGA"};


    while(i+2 <= len){
        if(s.substr(i,3)=="ATG"){ //search a substring in s starting at s and having a length 3
            int j = i+3;
            while(j+2<=len){
                if(stop.find(s.substr(j,3))!=stop.end()){ //if the find does not find a result it gives us stop.end()
                   return s.substr(i,j+2-i+1);
/*
i=position where start codon
j=position where end first letter stop codon, we have to sum 2 to have the entire codon.
+1 to have the entire sequence
*/                   
                }
                j=j+3;
            }

        }
        i=i+1;
    }
    return "";
    
}


    /*
HOW TO EXECUTE A C++ CODE?

g++ -o ejecutable_file_name file_name.cpp
./ejecutable_file_name
*/

