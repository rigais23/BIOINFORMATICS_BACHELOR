#include <iostream>
#include <vector>

using namespace std;

int which(vector<int> in){
	int n=in.size()+1;
	int expected=(n*(n+1)/2);
	int suma=0;
	for(int x: in){
		suma+=x;
		}
	return(expected-suma);
	
	}
	

int main(){
	int how;
	int num;
	
	while(cin>>how){
		how=how-1;
		vector<int> numbers(how);
		for(int i=0;i<how;i++){
			cin>>num;
			numbers[i]=num;
			}
		int result=which(numbers);
		cout<<result<<endl;
		}
	
	return 0;
}
