#include <iostream>
#include <string>


using namespace std;

void product_of_digits(int number){
	if(number<10){
		cout << "The product of the digits of " << number << " is " << number << "." << endl;
	}
	while(number>=10){
		int product=1;
		string number_string=to_string(number);
		for (char dig : number_string) {
		product *= dig - '0';
		}
		cout<<"The product of the digits of "<<number<<" is "<<product<<'.'<<endl;
		number=product;
	}
	
	cout<<"----------"<<endl;
		
}

int main(){
	int number;
	while(cin>>number){	
		product_of_digits(number);
		
	}
	return 0;
	}
