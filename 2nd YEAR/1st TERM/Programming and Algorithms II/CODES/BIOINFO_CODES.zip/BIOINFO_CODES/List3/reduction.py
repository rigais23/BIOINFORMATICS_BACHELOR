def sum_of_digits(x): #compute sum of digits of a number
	if x<=9:
		return x
	else:
		return x%10 + sum_of_digits(x//10)

def reduction_of_digits(x): ###compute the sum of digits until the number is only a digit
	if x<=9:
		return x
	
	else:
		return reduction_of_digits(sum_of_digits(x))
