#include <iostream>

using namespace std;

int sum_of_digits(int x){
	if(x<=9){
		return x;
	}
	else{
		return x%10+sum_of_digits(x/10);
	}

}

int reduction_of_digits(int x) {
    if (x <= 9) {
        return x;
    } 
    else {
        return reduction_of_digits(sum_of_digits(x));
    }
}

int main(){
	int num;
	cin>>num;
	
	int result = reduction_of_digits(num);
	cout<<result<<endl;
	return 0;
}
