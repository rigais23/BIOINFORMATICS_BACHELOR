import sys

def which(sequence):
	how=sequence[0]
	suma_elements=sum(sequence[1:])
	suma_expected=(how*(how+1)//2)
	nombre_faltant=suma_expected-suma_elements
	return nombre_faltant
	
	
for line in sys.stdin:
	l=line.strip().split()   #strip--> sense espais, sense fi lines #split --> cada element en una llista
	#we create a list for each line of the input, each number is a elemen of the line
	b=[]
	for x in l:
		b.append(int(x))#convert each element of the list into integer
	result=which(b)
	print(result)
