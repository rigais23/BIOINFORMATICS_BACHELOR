import sys

def interleaving(x,y):
	result=''
	x=str(x)
	y=str(y)
	while int(y)>9:
		if int(x) > 9:
			x=str(x)
			result+=x[0]
			x=x[1:]
		
		if int(y) > 9:
			y=str(y)
			result+=y[0]
			y=y[1:]
	result+=str(x[0])
	result+=str(y[0])
	return result
		
	





for elem in sys.stdin:
	numbers=elem.strip().split()
	first=int(numbers[0])
	second=int(numbers[1])
	
	what=interleaving(first,second)
	print(what)

