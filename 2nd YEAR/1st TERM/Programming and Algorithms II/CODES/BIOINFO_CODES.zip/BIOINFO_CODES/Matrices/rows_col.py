import sys

first=sys.stdin.readline().strip().split()
rows=int(first[0])
columns=int(first[1])

matrix=list()
for _ in range(rows):
	fila=sys.stdin.readline().strip().split()
	matrix.append(fila)
'''
q1=sys.stdin.readline.strip().split()
q11=int(q1[1])
q2=ssys.stdin.readline.strip().split()
q22=int(q2[1])
q3=sys.stdin.readline.strip().split()
q31=int(q3[1])
q32=int(q3[2])
q4=sys.stdin.readline.strip().split()
q44=int(q4[1])

for r in range(rows):
	if r ==q11:
		result1=matrix[r]
		break

result2=list()
for r in range(rows):
	for c in range(columns):
		if c==q22:
			result2.append(matrix[r][c])
			break
			
for r in range(rows):
	for c in range(columns):
		if r==q31 and c==q32:
			result3=matrix[r][c]

for r in range(rows):
	if r ==q4:
		result4=matrix[r]
		break

print(result1,result2,result3,result4)

'''
result1 = "row {}: {}".format(q11, " ".join(matrix[q11 - 1]))

result2 = "column {}: {}".format(q22, " ".join(matrix[r][q22 - 1] for r in range(rows)))

result3 = "element {} {}: {}".format(q31, q32, matrix[q31 - 1][q32 - 1])

result4 = "row {}: {}".format(q44, " ".join(matrix[q44 - 1]))

print(result1)
print(result2)
print(result3)
print(result4)
