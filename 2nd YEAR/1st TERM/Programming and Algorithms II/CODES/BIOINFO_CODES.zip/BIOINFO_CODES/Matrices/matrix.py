#UNA MATRIU ES UNA LLISTA DE LLISTES --> [[],[],[]]
matrix = [
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 9]
]

#PER ACCEDIR ALS ELEMENTS D'UNA MATRIU HEM D'INDEXAR M[R][C].

#M[][] --> el primer [] es refereix a les ROWS i el segon [] a les COLUMNES.

#PER SABER EL NOMBRE DE ROWS: --> 3.
	len(MATRIX) 

#PER SABER EL NOMBRE DE COLUMNES: --> 3.
	len(MATRIX[0])


#Modificacio llistes
	llista=[a,b,c,d]
	llista[1]=d --> [a,d,c,d]
		


###############################################
def symmetric(M):
	#symmetric --> len(MATRIX) = len(MATRIX[0])
	n=len(M)
	
	for r in range(n): #ROWS
		for c in range(n): #COLUMNS
			if M[r][c] != M[c][r]:
				return False #si s'arriba s'acaba la funcio
	
	return True #si no passa lu anterior vol dir que es simmetrica
################################################



n=int(input())
#PER CREAR UNA MATRIU:
	#QUADRADA nxn
	
	M=list() #MATRIU
	
	for r in range(n):
		R=list() #ROWS
		
		for c in range(n):
			R.append(0)#COLUMNES
		M.append(R)

m=int(input())
#MODIFICACIO DE LA MATRIU
for x in range(m): # --> 2
	linia=sys.stdin.readline().strip().split() #strip --> treu coses, #split --> fa una llista
	#[3,1,2,3]
	posicio_r=linia[0] #--> 3
	
	#Modificar matriu
	for y in range(n): #n-->3; y=1
		M[posicio_r-1][y]=linia[y+1]


#IMPRIMIR MATRIU
for linia in M:
	for num in linia:
		print(num,end='')
	print()
'''
	
	
		
	
