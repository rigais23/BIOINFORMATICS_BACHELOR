#include <iostream>
#include <string>
#include<map>
#include<set>

using namespace std;

string RNA2PROTEIN(string seq);

int main(){
    string seq;
    cin >> seq;
    string x = RNA2PROTEIN(seq);

    if(x != ""){
        cout<< x<< endl;
    }
    return 0;
}

string RNA2PROTEIN(string seq){
    int leng=seq.length();
    set<string> stop= {"UGA","UAA","UAG"};
    int i=0;
    string trans="";
    
    map<string,string> dict =  {
        {"AAA", "K"}, {"AAC", "N"}, {"AAG", "K"}, {"AAU", "N"},
        {"ACA", "T"}, {"ACC", "T"}, {"ACG", "T"}, {"ACU", "T"},
        {"AGA", "R"}, {"AGC", "S"}, {"AGG", "R"}, {"AGU", "S"},
        {"AUA", "I"}, {"AUC", "I"}, {"AUG", "M"}, {"AUU", "I"},
        {"CAA", "Q"}, {"CAC", "H"}, {"CAG", "Q"}, {"CAU", "H"},
        {"CCA", "P"}, {"CCC", "P"}, {"CCG", "P"}, {"CCU", "P"},
        {"CGA", "R"}, {"CGC", "R"}, {"CGG", "R"}, {"CGU", "R"},
        {"CUA", "L"}, {"CUC", "L"}, {"CUG", "L"}, {"CUU", "L"},
        {"GAA", "E"}, {"GAC", "D"}, {"GAG", "E"}, {"GAU", "D"},
        {"GCA", "A"}, {"GCC", "A"}, {"GCG", "A"}, {"GCU", "A"},
        {"GGA", "G"}, {"GGC", "G"}, {"GGG", "G"}, {"GGU", "G"},
        {"GUA", "V"}, {"GUC", "V"}, {"GUG", "V"}, {"GUU", "V"},
        {"UAA", "-"}, {"UAC", "Y"}, {"UAG", "-"}, {"UAU", "Y"},
        {"UCA", "S"}, {"UCC", "S"}, {"UCG", "S"}, {"UCU", "S"},
        {"UGA", "-"}, {"UGC", "C"}, {"UGG", "W"}, {"UGU", "C"},
        {"UUA", "L"}, {"UUC", "F"}, {"UUG", "L"}, {"UUU", "F"}
    };

    while((i+2)<leng){
        if(seq.substr(i,3)=="AUG"){
            int j=i+3;
            while((j+2)<leng){
                if(stop.find(seq.substr(j,3)) != stop.end()){
                    return(trans);
                }
                else{
                    trans+=dict[seq.substr(j,3)];
                    j+=3;
                }
            }
        }
        i+=1;
    }
    return("");


}


