#include <iostream>
#include <string>
#include <map>
#include <vector>
#include <algorithm>

using namespace std;

string REVERSED_COMPLEMENT(string w){
    string r="";
    for(int i=0; i < w.length();++i){
        if(w[i]=='A'){
            r='T'+r;
        }
        if(w[i]=='T'){
            r='A'+r;
        }
        else if(w[i]=='G'){
            r='C'+r;
        }
        if(w[i]=='C'){
            r='G'+r;
        }
    }
    return r;
}

map<string, int> READ_ABUNDANCE(vector<string> seqi){
    map<string, int> dic;
    for(int i=0; i < seqi.size();++i){
        string sequ=seqi[i];
        string rev=REVERSED_COMPLEMENT(sequ);
        if(rev < sequ){
            sequ=rev;
        }
        if(dic.find(sequ) != dic.end()){//default value if not found is dic.end()
            dic[sequ]++;//add 1
        }
        else{
            dic[sequ]=1;
        }

    }
    return dic;
}


int main(){
    vector<string> sequences;
    string x;
    while(cin>>x){
        sequences.push_back(x);
    }

    map<string,int> def_dic=READ_ABUNDANCE(sequences);
    for(auto entry:def_dic){
        cout << entry.first << " " << entry.second << endl;
    }   
    return 0;
}
