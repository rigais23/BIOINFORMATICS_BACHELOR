from pytokr import *

def REVERSED_COMPLEMENT(w):
    r=''
    for let in w:
        if let=='A':
            r='T'+r
        elif let=='T':
            r='A'+r
        elif let=='C':
            r='G'+r
        elif let=='G':
            r='C'+r
    return r

def READ_ABUNDANCE(seqi):
    dic=dict()

    for seq in seqi:
        rev=REVERSED_COMPLEMENT(seq)
        seq=min(rev,seq) #to sort alpabetically and choose the smallest
        if seq in dic:
            dic[seq]+=1
        else:
            dic[seq]=1
    
    return dic

##########################################
        
sequences=list()
for read in items():
    sequences.append(read)

def_dic=READ_ABUNDANCE(sequences)

for key in sorted(def_dic): #sort dictionary alphabetically
    print(key,def_dic[key])

###########################################