import sys

s=sys.stdin.readline().strip()

def suffix_array(s):
    A=list()
    i=0
    n=len(s)

    for x in range(n):
        A.append(s[x:n])
    
    A_s=sorted(A)

    R=list()

    for y in range(n):
        R.append(n-len(A_s[y])+1)
    
    return R

x=suffix_array(s)

for results in x:
    print(results)