#include <iostream>
#include <vector>
#include <string>
#include <algorithm>

using namespace std;

vector<int> suffix_array(string s){
    vector<string> A;
    int len=s.length();
    for(int a=0;a<len;a++){
        A.push_back(s.substr(a));
    }
    sort(A.begin(),A.end());
    
    vector<int> R;

    for(int y=0;y<len;y++){
        R.push_back(len-(A[y].length())+1);
    }
    return R;

}


int main(){
    string sequence;
    cin >> sequence;

    vector<int> result=suffix_array(sequence);
    for(int i=0; i<result.size();i++){
        cout<<result[i]<<endl;
    }
    return 0;
}