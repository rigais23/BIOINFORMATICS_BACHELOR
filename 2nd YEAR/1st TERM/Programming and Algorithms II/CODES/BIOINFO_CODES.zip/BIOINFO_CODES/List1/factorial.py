def factorial(n):
    n=int(n)
    result=1
    for x in range(1,n+1):
        result=result*x
    return result

