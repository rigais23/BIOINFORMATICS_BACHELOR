#include <iostream>
#include <iomanip>

using namespace std;

int main(){
    int count = 0;
    double sum = 0.0;
    double num = 0.0;

    while(cin >> num){
        sum+=num;
        count++;
    }
    cout << fixed << setprecision(2);
    cout<<(sum/count)<<endl;

    return 0;

}