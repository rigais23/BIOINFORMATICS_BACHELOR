#include <iostream>
#include <iomanip>

using namespace std;

double sum_of_fract(int a, int b, int k){

    int denom=a;
    double frac=0.0;

    while((denom)<=b){
        frac = frac + (1.0/denom);
        denom = denom + k;
    }
    return frac;
}


int main(){
    int a, b, k;
    
    while(cin >> a >> b >>k){
        double result=sum_of_fract(a, b, k);
        cout << fixed << setprecision(4) << result << endl;
    }
    return 0;

}

