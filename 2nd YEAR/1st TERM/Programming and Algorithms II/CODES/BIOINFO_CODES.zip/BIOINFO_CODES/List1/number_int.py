from pytokr import *

first=int(item())
second=int(item())

if first == second:
    print(first)

elif first > second:
    print()

else:
    result = ','.join(map(str, range(first, second + 1)))
    print(result)
