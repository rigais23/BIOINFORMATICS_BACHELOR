from pytokr import *



for a in items():
    a=int(a)
    b=int(item())
    k=int(item())

    denom=a

    frac=0

    while denom <= b:
        frac+=(1/denom)
        denom+=k
    
    print(f"{frac:.4f}")

