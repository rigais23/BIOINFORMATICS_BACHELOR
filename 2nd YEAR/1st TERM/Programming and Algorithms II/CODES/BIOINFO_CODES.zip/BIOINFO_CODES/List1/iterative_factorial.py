def factorial(n):
	if n<=1: #can also be 0
		return 1 #input can be 0 and therefore result will be 0, IS 1
	else:
		return n*factorial(n-1)

