#include <iostream>

using namespace std;


int main(){
    int start;
    int end;

    cin >> start;
    cin >> end;

    if(start<end){
        for(int i =start; i<=end; i++){
            cout <<i;
            if(i <end){
                cout <<',';
            }
        }
        cout << endl;        
    }
    else if(start==end){
        cout<<start<<endl;
    }

    else{
        cout<<""<< endl;
        
    }
    return 0;


}