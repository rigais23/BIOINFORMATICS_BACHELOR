#include <iostream>
#include <vector>
#include <string>
#include <set>
#include <algorithm>

using namespace std;

vector<string> SUBWORDS(string s){
	int n=s.length();
	set<string> norep;
	
	for(int i=0; i<n; i++){
		for(int j=i; j<n; j++){
			norep.insert(s.substr(i,j-i+1));
		}
	
	}
	vector<string> L;
	
	for (string subword : norep) {
        L.push_back(subword);
	}
	sort(L.begin(),L.end());
	
	return L;

}

int main(){
	string word;
	cin >> word;
	
	vector<string> result=SUBWORDS(word);
	
	for(string what: result){
		cout<<what<<endl;
		}
	
	return 0;
	}
