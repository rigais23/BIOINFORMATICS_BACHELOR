import sys

word=sys.stdin.readline().strip()

def SUBWORDS(s):
	L=set()
	SUBWORDSa(s,L)
	return L
	
def SUBWORDSa(s,L):
	if len(s)==0:
		return L
	else:
		for x in range(len(s)):
			L.add(s[0:x+1])
		
		SUBWORDSa(s[1:],L)			
		
result=SUBWORDS(word)


for elem in sorted(result):
	print(elem)
