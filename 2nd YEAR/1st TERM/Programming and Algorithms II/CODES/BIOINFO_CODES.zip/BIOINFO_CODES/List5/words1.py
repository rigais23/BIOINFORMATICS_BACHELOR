import sys

def WORDS(n,dicc):
	sorted_dicc=sorted(dicc)
	L=[]
	L.append('')      #if we do NOT append an empty string the function does NOT work
	for _ in range(n): #do the iteration n times
		L_prime =[]     #create a new list for each iteration with all the new possible combinations
		for elem in L:   #get all elements in the list of n-1
			for x in sorted_dicc: 
				new=elem+x #add all the letters of our alphabet to the words of n-1
				L_prime.append(new)
		L=L_prime #upload the list with all new combinations
	
	return L




number=sys.stdin.readline().strip()
number=int(number)

alphabet=sys.stdin.readline().strip().split()

result= WORDS(number,alphabet)

for elem in result:
	print(elem)
