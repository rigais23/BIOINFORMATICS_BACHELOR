import sys


def REVERSED(q):
	rev=[]
	if len(q)==0:
		return rev
	
	else:
		return [q[-1]] + REVERSED(q[:-1]) 

def REVERSESI(s):
	new=list()
	slist=list()
	
	slist=SUB_REV(s,new,0)
	
	return REVERSED(slist)

def SUB_REV(s,new,i):
	if s[i]=='end':
		return new
	
	else:
		return [s[i]]+SUB_REV(s,new,i+1)







llista=[]
for elem in sys.stdin:
	name=elem.strip()
	llista.append(name)

result=REVERSESI(llista)

for elname in result:
	print(elname)

 
	
