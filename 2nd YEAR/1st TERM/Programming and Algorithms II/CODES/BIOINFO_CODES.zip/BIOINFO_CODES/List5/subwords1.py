import sys

word=sys.stdin.readline().strip()

def SUBWORD(s):
	n=len(s)
	S=set()
	
	for i in range(n):
		for j in range(i,n):
			S.add(s[i:j+1])
	
	L=list()
	
	for elem in S:
		L.append(elem)
	
	sorted_list=sorted(L)
	
	return sorted_list


result=SUBWORD(word)

for paraula in result:
	print(paraula)
		
		











