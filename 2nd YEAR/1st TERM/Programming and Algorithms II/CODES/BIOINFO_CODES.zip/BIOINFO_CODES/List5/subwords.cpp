#include <iostream>
#include <string>
#include <set>
#include <algorithm>

using namespace std;

void SUBWORDS_a(string s, set<string>& L);


set<string> SUBWORDS(string s){
	set<string> L;
	SUBWORDS_a(s, L);
	return L;
}


void SUBWORDS_a(string s, set<string>& L){
	if(s.length()==0){
		return;
		}
	
	else{
		for(int i=0; i<s.length();i++){
			L.insert(s.substr(0,i+1));
			}
			SUBWORDS_a(s.substr(1),L);
		}
}

int main(){
	string name;
	cin >> name;
	
	set<string> result=SUBWORDS(name);
		
	for(string sub: result){
		cout<<sub<<endl;
		}
	
	
	}
