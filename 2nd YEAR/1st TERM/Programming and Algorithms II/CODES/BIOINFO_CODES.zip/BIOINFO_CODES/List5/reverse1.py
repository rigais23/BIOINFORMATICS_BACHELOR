import sys

def REVERSED(q):
	rev=[]
	if len(q)==0:
		return rev
	
	else:
		return [q[-1]] + REVERSED(q[:-1]) 




llista=[]
for elem in sys.stdin:
	name=elem.strip()
	llista.append(name)

result=REVERSED(llista)


for elname in result:
	print(elname)
