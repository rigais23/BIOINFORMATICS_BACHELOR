#include <iostream>
#include <vector>
#include <string>

using namespace std;

vector<string> SUB_REV(const vector<string>& s, vector<string>& new_vector, int i);

vector<string> REVERSED(vector<string> q){
	vector<string> rev;
	
	if(q.size()==0){
		return rev;
		}
	
	else{
		rev.push_back(q.back());
		vector<string> rest = REVERSED(vector<string>(q.begin(), q.end() - 1));
		rev.insert(rev.end(), rest.begin(), rest.end());
		return rev;
		}
	}

vector<string> REVERSIS(vector<string> s){
	vector<string> newe;
	vector<string> slist = SUB_REV(s,newe, 0);
	return REVERSED(slist);
	
	}



vector<string> SUB_REV(const vector<string>& s, vector<string>& new_vector, int i) {
	if (s[i] == "end") {
		return new_vector;
	} else {
		new_vector.push_back(s[i]);
		SUB_REV(s, new_vector, i + 1);
		return new_vector;
	}
}


int main(){
	vector<string> llista;
	
	string name;
	
	while(cin>>name){
		llista.push_back(name);
	}
	vector<string> result= REVERSIS(llista);
	
	for(string namet: result){
		cout<<namet<<endl;
		}
	
	return 0;
	
	}
