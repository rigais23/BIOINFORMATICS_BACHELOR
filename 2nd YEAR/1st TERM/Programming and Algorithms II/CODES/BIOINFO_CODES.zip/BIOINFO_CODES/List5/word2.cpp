#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;

vector<string> WORDS(int n, vector<string> dicc){
	vector<string> L;
	sort(dicc.begin(),dicc.end());
	if(n==0){
		L.push_back("");
	}
	else{
		vector<string> W=WORDS(n-1,dicc);
		for(int o=0;o<W.size();o++){
			for(int y=0; y<dicc.size();y++){
				string newe=W[o]+dicc[y];
				L.push_back(newe);
			}
		}
		
	}
	return L;	
}


int main(){
	int number;
	cin >> number;
	string cosa;
	vector<string> alphabet;
	
	while(cin>>cosa){
		alphabet.push_back(cosa);
	}
	
	vector<string> result= WORDS(number,alphabet);
	
	for(string coseta: result){
		cout<<coseta<<endl;
		}
	return 0;
}
