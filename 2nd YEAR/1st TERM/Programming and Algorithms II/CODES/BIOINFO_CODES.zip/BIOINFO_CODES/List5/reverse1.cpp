#include <iostream>
#include <string>
#include <vector>

using namespace std;

vector<string> REVERSED(vector<string> names){
	vector<string> rev;

	if(names.size()==0){
		return rev;
		}
	
	else{
		string last=names.back(); 
		rev.push_back(last);
		
		vector<string> no_last(names.begin(),names.end()-1);
		vector<string> rest_rev = REVERSED(no_last);

		rev.insert(rev.end(),rest_rev.begin(),rest_rev.end());
		
		return rev;
	}





}


int main(){
	vector<string> llista;
	
	string name;
	
	while(cin>>name){
		llista.push_back(name);
	}
	vector<string> result= REVERSED(llista);
	
	for(string namet: result){
		cout<<namet<<endl;
		}
	
	return 0;
	
	}
