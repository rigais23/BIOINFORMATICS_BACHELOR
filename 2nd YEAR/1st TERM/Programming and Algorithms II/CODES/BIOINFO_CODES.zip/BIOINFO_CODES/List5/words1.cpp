#include <iostream>
#include <vector>
#include <string>
#include <algorithm>

using namespace std;

vector <string> WORDS(int n, vector<string> dicc){
	vector<string> L={""};
	sort(dicc.begin(),dicc.end());
	
	for(int i=0;i<n;i++){
		vector<string> L_prime;
		for(int o=0;o<L.size();o++){
			for(int y=0; y<dicc.size();y++){
				string newe=L[o]+dicc[y];
				L_prime.push_back(newe);				
			}		
		}
		L=L_prime;
	
	}
	return L;	
}

int main(){
	int num;
	cin>>num;
	vector<string> alphabet;
	string cosa;
	while(cin>>cosa){
		alphabet.push_back(cosa);
		}
	
	vector<string> result= WORDS(num,alphabet);
	
	for(string coseta: result){
		cout << coseta << endl;
	}
	return 0;
	
}
