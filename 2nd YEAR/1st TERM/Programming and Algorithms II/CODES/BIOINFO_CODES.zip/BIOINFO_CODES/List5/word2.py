import sys

def WORDS(length, dicc):
	L=[]
	if length==0:
		L.append('')
	
	else:
		W=WORDS(length-1,dicc)
		for w in W:
			for x in dicc:
				new=w+x
				L.append(new)
	return L 


number=sys.stdin.readline().strip()
number=int(number)

alphabet=sys.stdin.readline().strip().split()

result=WORDS(number,alphabet)

for ele in sorted(result):
	print(ele)
