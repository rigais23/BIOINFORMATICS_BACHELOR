import sys

def is_increasing(n):
	if len(n) <= 1:
		return True
	
	elif int(n[0])>int(n[1]):
		return False
	
	else:
		return is_increasing(n[1:])



s=sys.stdin.readline().strip()

result=is_increasing(s)

print(result)
