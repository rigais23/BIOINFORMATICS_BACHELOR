#include <iostream>
#include <vector>
#include <string>

using namespace std;

vector<string> BARS2(int n){
	vector<string> L;
	
	if(n==1){
		L.push_back("*");
		
		return L;	
	}
	
	else{
		string bars=string(n,'*');
		L.push_back(bars);
		vector<string> prev=BARS2(n-1);
		
		L.insert(L.begin(),prev.begin(),prev.end());
		L.insert(L.begin(),prev.begin(),prev.end());

		return L;
		}
}

int main(){
	int num;
	cin>>num;
	
	vector<string> result=BARS2(num);
	
	for(string elem: result){
		cout<<elem<<endl;
		}
	return 0;
	}
