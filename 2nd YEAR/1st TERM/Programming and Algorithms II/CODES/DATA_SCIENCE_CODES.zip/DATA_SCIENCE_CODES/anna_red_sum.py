import sys

def SUM(n):
	if n<=9:
		return n
	
	else:
		return n%10+SUM(n//10)

def RED(n):
	if n<=9:
		return n
	
	else:
		return RED(SUM(n))

num=sys.stdin.readline().strip()

num=int(num)

result=RED(num)

print(result)
