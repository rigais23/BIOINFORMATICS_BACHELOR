#include <iostream>
#include <string>

using namespace std;

bool is_increasing(string s){
	char sub1 = s[0];
	char sub2 = s[1];
	
	if(s.length()==1){
		return true;
		}
	else if((sub1-'0')>(sub2-'0')){
		return false;
		}
	
	else{
		return is_increasing(s.substr(1));
		}
}


int main(){
	string num;
	cin>>num;
	
	bool result=is_increasing(num);
	
	cout<<result<<endl;
	
	return 0;
	
	
	
	}



