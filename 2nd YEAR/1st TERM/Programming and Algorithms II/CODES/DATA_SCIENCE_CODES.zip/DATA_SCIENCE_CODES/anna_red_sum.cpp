#include <iostream>

using namespace std;

int SUM(int n){
	if(n<=9){
		return n;
	}
	else{
		return n%10+SUM(n/10);
	}
}


int RED(int n){
	if(n<=9){
		return n;
	}
	else{
		return RED(SUM(n));
	}
}

int main(){
	int num;
	cin>>num;
	
	int result=RED(num);
	
	cout<<result<<endl;
	
	return 0;
	
}
